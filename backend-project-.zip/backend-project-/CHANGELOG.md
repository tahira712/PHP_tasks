CHANGELOG
=========

 V 3.0.0
-------
 - Revamped Template

 V 2.0.0
-------
 - Bootstrap5

 V 1.0.1
-------
 - Updated all outdated packages
 - Bug fixes

V 1.0.0
-------
 - Initial release
